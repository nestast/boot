ipykernel.comm package
======================

Submodules
----------


.. automodule:: ipykernel.comm.comm
   :members:
   :undoc-members:
   :show-inheritance:


.. automodule:: ipykernel.comm.manager
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ipykernel.comm
   :members:
   :undoc-members:
   :show-inheritance:
